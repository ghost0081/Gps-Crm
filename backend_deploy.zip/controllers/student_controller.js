const bcrypt = require('bcrypt');
const Student = require('../models/studentSchema.js');
const Subject = require('../models/subjectSchema.js');

const studentRegister = async (req, res) => {
    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPass = await bcrypt.hash(req.body.password, salt);

        const existingStudent = await Student.findOne({
            rollNum: req.body.rollNum,
            school: req.body.adminID,
            sclassName: req.body.sclassName,
        });

        if (existingStudent) {
            res.send({ message: 'Roll Number already exists' });
        }
        else {
            const student = new Student({
                ...req.body,
                school: req.body.adminID,
                password: hashedPass
            });

            let result = await student.save();
            result.password = undefined;
            res.send(result);
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

const studentLogIn = async (req, res) => {
    try {
        let student = await Student.findOne({ rollNum: req.body.rollNum, name: req.body.studentName });
        if (student) {
            const validated = await bcrypt.compare(req.body.password, student.password);
            if (validated) {
                student = await student.populate("school", "schoolName")
                student = await student.populate("sclassName", "sclassName")
                student.password = undefined;
                student.examResult = undefined;
                student.attendance = undefined;
                res.send(student);
            } else {
                res.send({ message: "Invalid password" });
            }
        } else {
            res.send({ message: "Student not found" });
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

const getStudents = async (req, res) => {
    try {
        let students = await Student.find({ school: req.params.id }).populate("sclassName", "sclassName");
        if (students.length > 0) {
            let modifiedStudents = students.map((student) => {
                return { ...student._doc, password: undefined };
            });
            res.send(modifiedStudents);
        } else {
            res.send({ message: "No students found" });
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

const getStudentDetail = async (req, res) => {
    try {
        let student = await Student.findById(req.params.id)
            .populate("school", "schoolName")
            .populate("sclassName", "sclassName")
            .populate("examResult.subName", "subName")
            .populate("attendance.subName", "subName sessions");
        if (student) {
            student.password = undefined;
            res.send(student);
        }
        else {
            res.send({ message: "No student found" });
        }
    } catch (err) {
        res.status(500).json(err);
    }
}

const deleteStudent = async (req, res) => {
    try {
        const result = await Student.findByIdAndDelete(req.params.id)
        res.send(result)
    } catch (error) {
        res.status(500).json(err);
    }
}

const deleteStudents = async (req, res) => {
    try {
        const result = await Student.deleteMany({ school: req.params.id })
        if (result.deletedCount === 0) {
            res.send({ message: "No students found to delete" })
        } else {
            res.send(result)
        }
    } catch (error) {
        res.status(500).json(err);
    }
}

const deleteStudentsByClass = async (req, res) => {
    try {
        const result = await Student.deleteMany({ sclassName: req.params.id })
        if (result.deletedCount === 0) {
            res.send({ message: "No students found to delete" })
        } else {
            res.send(result)
        }
    } catch (error) {
        res.status(500).json(err);
    }
}

const updateStudent = async (req, res) => {
    try {
        if (req.body.password) {
            const salt = await bcrypt.genSalt(10)
            req.body.password = await bcrypt.hash(req.body.password, salt)
        }
        let result = await Student.findByIdAndUpdate(req.params.id,
            { $set: req.body },
            { new: true })

        result.password = undefined;
        res.send(result)
    } catch (error) {
        res.status(500).json(err);
    }
}

const updateExamResult = async (req, res) => {
    const { subName, marksObtained } = req.body;

    try {
        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.send({ message: 'Student not found' });
        }

        const existingResult = student.examResult.find(
            (result) => result.subName.toString() === subName
        );

        if (existingResult) {
            existingResult.marksObtained = marksObtained;
        } else {
            student.examResult.push({ subName, marksObtained });
        }

        const result = await student.save();
        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};

const studentAttendance = async (req, res) => {
    const { subName, status, date } = req.body;

    try {
        const student = await Student.findById(req.params.id);

        if (!student) {
            return res.send({ message: 'Student not found' });
        }

        const subject = await Subject.findById(subName);

        const existingAttendance = student.attendance.find(
            (a) =>
                a.date.toDateString() === new Date(date).toDateString() &&
                a.subName.toString() === subName
        );

        if (existingAttendance) {
            existingAttendance.status = status;
        } else {
            // Check if the student has already attended the maximum number of sessions
            const attendedSessions = student.attendance.filter(
                (a) => a.subName.toString() === subName
            ).length;

            if (attendedSessions >= subject.sessions) {
                return res.send({ message: 'Maximum attendance limit reached' });
            }

            student.attendance.push({ date, status, subName });
        }

        const result = await student.save();
        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};

const clearAllStudentsAttendanceBySubject = async (req, res) => {
    const subName = req.params.id;

    try {
        const result = await Student.updateMany(
            { 'attendance.subName': subName },
            { $pull: { attendance: { subName } } }
        );
        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};

const clearAllStudentsAttendance = async (req, res) => {
    const schoolId = req.params.id

    try {
        const result = await Student.updateMany(
            { school: schoolId },
            { $set: { attendance: [] } }
        );

        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};

const removeStudentAttendanceBySubject = async (req, res) => {
    const studentId = req.params.id;
    const subName = req.body.subId

    try {
        const result = await Student.updateOne(
            { _id: studentId },
            { $pull: { attendance: { subName: subName } } }
        );

        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};


const removeStudentAttendance = async (req, res) => {
    const studentId = req.params.id;

    try {
        const result = await Student.updateOne(
            { _id: studentId },
            { $set: { attendance: [] } }
        );

        return res.send(result);
    } catch (error) {
        res.status(500).json(err);
    }
};

const studentAttendanceBulk = async (req, res) => {
    const { attendanceRecords, subName, date } = req.body;
    // attendanceRecords format: [{ studentId: "id", status: "Present" | "Absent" }]

    try {
        const subject = await Subject.findById(subName);
        if (!subject) {
            return res.status(404).send({ message: 'Subject not found' });
        }

        const results = [];
        for (const record of attendanceRecords) {
            const { studentId, status } = record;
            const student = await Student.findById(studentId);

            if (!student) continue;

            // Find existing attendance for this subject on this date
            const existingAttendance = student.attendance.find(
                (a) =>
                    a.date.toDateString() === new Date(date).toDateString() &&
                    a.subName.toString() === subName
            );

            if (existingAttendance) {
                existingAttendance.status = status;
            } else {
                // Check if the student has already reached the maximum number of sessions
                const attendedSessions = student.attendance.filter(
                    (a) => a.subName.toString() === subName
                ).length;

                if (attendedSessions < subject.sessions) {
                    student.attendance.push({ date, status, subName });
                }
            }
            await student.save();
            results.push(student._id);
        }

        return res.send({ message: 'Bulk attendance recorded successfully', count: results.length });
    } catch (error) {
        res.status(500).json({ message: 'Error updating bulk attendance', error: error.message });
    }
};

const registerStudentFace = async (req, res) => {
    try {
        const studentId = req.params.id;
        const student = await Student.findById(studentId);
        
        if (!student) {
            return res.status(404).send({ message: 'Student not found' });
        }

        if (!req.files || req.files.length === 0) {
            return res.status(400).send({ message: 'No images provided' });
        }

        const embeddings = [];
        for (const file of req.files) {
            const formData = new FormData();
            const blob = new Blob([file.buffer], { type: file.mimetype });
            formData.append('image', blob, file.originalname);

            const pyRes = await fetch('http://face-recognition-api:8000/extract-embedding', {
                method: 'POST',
                body: formData
            });

            const pyData = await pyRes.json();
            if (pyRes.ok && pyData.embedding) {
                embeddings.push(pyData.embedding);
            }
        }

        if (embeddings.length === 0) {
            return res.status(400).send({ message: 'Failed to extract face from any provided image' });
        }

        // We store the multiple embeddings in faceEmbeddings
        student.faceEmbeddings = embeddings;
        // Tell mongoose that the Mixed field has been modified
        student.markModified('faceEmbeddings');
        await student.save();

        res.send({ message: 'Face(s) registered successfully', student });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

const markAttendanceByFace = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).send({ message: 'No image provided' });
        }

        const students = await Student.find({ faceEmbeddings: { $exists: true, $not: {$size: 0} }, school: req.body.schoolId });
        
        if (students.length === 0) {
            return res.status(404).send({ message: 'No registered faces found in database' });
        }

        const formData = new FormData();
        const blob = new Blob([req.file.buffer], { type: req.file.mimetype });
        formData.append('image', blob, req.file.originalname);

        const extRes = await fetch('http://face-recognition-api:8000/extract-embedding', {
            method: 'POST',
            body: formData
        });

        const extData = await extRes.json();
        if (!extRes.ok || !extData.embedding) {
            return res.status(400).send({ message: extData.message || 'Failed to extract face from provided image' });
        }

        const knownEmbeddings = {};
        students.forEach(s => {
            if (s.faceEmbeddings && s.faceEmbeddings.length > 0) {
                // If the first element is an array, we have an array of arrays (multiple embeddings)
                if (Array.isArray(s.faceEmbeddings[0])) {
                    s.faceEmbeddings.forEach((emb, idx) => {
                        knownEmbeddings[`${s._id.toString()}_${idx}`] = emb;
                    });
                } else {
                    // Backwards compatibility for single 1D array
                    knownEmbeddings[`${s._id.toString()}_0`] = s.faceEmbeddings;
                }
            }
        });

        const recRes = await fetch('http://face-recognition-api:8000/recognize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                embedding: extData.embedding,
                known_embeddings: knownEmbeddings
            })
        });

        const recData = await recRes.json();

        if (!recRes.ok || !recData.matched_id) {
            return res.status(400).send({ message: recData.message || 'No matching face found' });
        }

        const actualId = recData.matched_id.split('_')[0];
        const matchedStudent = students.find(s => s._id.toString() === actualId);

        const date = req.body.date || new Date();
        const status = req.body.status || 'Present';
        const subName = req.body.subName;

        if (!subName) {
            return res.status(400).send({ message: 'Subject name required to mark attendance', matchedStudent });
        }

        const subject = await Subject.findById(subName);
        if (!subject) return res.status(404).send({ message: 'Subject not found' });

        const existingAttendance = matchedStudent.attendance.find(
            (a) =>
                a.date.toDateString() === new Date(date).toDateString() &&
                a.subName.toString() === subName
        );

        if (existingAttendance) {
            existingAttendance.status = status;
        } else {
            matchedStudent.attendance.push({ date, status, subName });
        }

        await matchedStudent.save();

        res.send({ message: 'Attendance marked automatically via Face Recognition', student: matchedStudent, matchScore: recData.score });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

module.exports = {
    studentRegister,
    studentLogIn,
    getStudents,
    getStudentDetail,
    deleteStudents,
    deleteStudent,
    updateStudent,
    studentAttendance,
    deleteStudentsByClass,
    updateExamResult,

    clearAllStudentsAttendanceBySubject,
    clearAllStudentsAttendance,
    removeStudentAttendanceBySubject,
    removeStudentAttendance,
    studentAttendanceBulk,
    registerStudentFace,
    markAttendanceByFace
};