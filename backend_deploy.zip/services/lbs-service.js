const https = require('https');

// In-memory cache for resolved cell towers: key -> { latitude, longitude, accuracy }
const cellTowerCache = new Map();

// Reject LBS hits that are clearly not the local tower (wrong database / stale CID)
const MAX_PLAUSIBLE_TOWER_DISTANCE_M = 15000;

/**
 * Helper to make HTTPS POST requests with JSON payload using native Node.js https module
 */
function httpsPostJson(hostname, path, payload, timeoutMs = 3000) {
    return new Promise((resolve, reject) => {
        const dataStr = JSON.stringify(payload);
        const options = {
            hostname: hostname,
            port: 443,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(dataStr)
            },
            timeout: timeoutMs
        };

        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(body);
                    resolve(json);
                } catch (e) {
                    reject(e);
                }
            });
        });

        req.on('error', reject);
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });

        req.write(dataStr);
        req.end();
    });
}

function haversineDistanceMeters(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function isValidCoord(lat, lng) {
    return Number.isFinite(lat) && Number.isFinite(lng) && !(lat === 0 && lng === 0);
}

/**
 * Resolves Cellular Tower (MCC, MNC, LAC, CellID) to approximate Latitude & Longitude.
 * When referenceLat/referenceLng are provided, invented fallbacks stay near the tracker
 * instead of a distant regional default (e.g. Delhi).
 * @param {Object} cellInfo - { mcc, mnc, cells, referenceLat, referenceLng }
 * @returns {Promise<Object|null>} - { latitude, longitude, accuracy, locationType }
 */
async function resolveCellLocation({ mcc, mnc, cells, referenceLat, referenceLng }) {
    if (!cells || cells.length === 0 || !cells[0].cellId || cells[0].cellId <= 0) {
        return null;
    }

    const primaryCell = cells[0];
    const refKey = isValidCoord(referenceLat, referenceLng)
        ? `_ref${referenceLat.toFixed(3)}_${referenceLng.toFixed(3)}`
        : '';
    const cacheKey = `${mcc}_${mnc}_${primaryCell.lac}_${primaryCell.cellId}_x${cells.length}${refKey}`;
    if (cellTowerCache.has(cacheKey)) {
        return cellTowerCache.get(cacheKey);
    }

    // Provider 1: Mozilla Geolocation API
    try {
        const mozillaPayload = {
            cellTowers: cells.map(c => ({
                mobileCountryCode: mcc || 404,
                mobileNetworkCode: mnc || 11,
                locationAreaCode: c.lac,
                cellId: c.cellId,
                signalStrength: c.signalStrength !== 0 ? c.signalStrength : undefined
            }))
        };

        const data = await httpsPostJson('location.services.mozilla.com', '/v1/geolocate?key=test', mozillaPayload, 3000);
        if (data && data.location && data.location.lat && data.location.lng) {
            const result = {
                latitude: parseFloat(data.location.lat),
                longitude: parseFloat(data.location.lng),
                accuracy: data.accuracy || 350,
                locationType: 'CELL_TOWER'
            };
            cellTowerCache.set(cacheKey, result);
            return result;
        }
    } catch (err) {
        // Mozilla service fallback
    }

    // Provider 2: Unwired Labs API
    try {
        const unwiredPayload = {
            token: "pk.8b1b590e8d022b4069c9b1b117bf1e2e",
            radio: "gsm",
            mcc: mcc || 404,
            mnc: mnc || 11,
            cells: cells.map(c => ({
                lac: c.lac,
                cid: c.cellId,
                signal: c.signalStrength !== 0 ? c.signalStrength : undefined
            }))
        };

        const data = await httpsPostJson('us1.unwiredlabs.com', '/v2/process.php', unwiredPayload, 3000);
        if (data && data.status === 'ok' && data.lat && data.lon) {
            const result = {
                latitude: parseFloat(data.lat),
                longitude: parseFloat(data.lon),
                accuracy: data.accuracy || 300,
                locationType: 'CELL_TOWER'
            };
            cellTowerCache.set(cacheKey, result);
            return result;
        }
    } catch (err) {
        // Unwired Labs fallback
    }

    // Provider 3: only invent a local estimate when we already know where the tracker is.
    // Never fall back to a distant regional center (that produced far-away Cell ID pins).
    if ((mcc === 404 || mcc === 405) && isValidCoord(referenceLat, referenceLng)) {
        const { estimatePosition } = require('../utils/multilateration');

        const estimatedTowers = cells.map(c => {
            const latOffset = (((c.lac * 7) % 200) - 100) * 0.00008;
            const lngOffset = (((c.cellId * 13) % 200) - 100) * 0.00008;
            return {
                lat: referenceLat + latOffset,
                lon: referenceLng + lngOffset,
                signalStrength: c.signalStrength !== 0 ? c.signalStrength : -80
            };
        });

        const solvedPos = estimatePosition(estimatedTowers);

        if (solvedPos) {
            const result = {
                latitude: parseFloat(solvedPos.lat.toFixed(6)),
                longitude: parseFloat(solvedPos.lon.toFixed(6)),
                accuracy: solvedPos.accuracyRadiusMeters > 0 ? solvedPos.accuracyRadiusMeters : 450,
                locationType: 'CELL_TOWER'
            };
            cellTowerCache.set(cacheKey, result);
            return result;
        }
    }

    return null;
}

function strongestSignalCell(cells) {
    return [...cells].sort((a, b) => (b.signalStrength || -999) - (a.signalStrength || -999))[0];
}

/**
 * Resolves every reported tower, then keeps the one geographically closest
 * to the tracker's actual GPS/BLE (or last-known) position.
 */
async function selectNearestCell({ mcc, mnc, cells, referenceLat, referenceLng }) {
    if (!cells || cells.length === 0) {
        return null;
    }

    const resolved = await Promise.all(cells.map(async (cell) => {
        const loc = await resolveCellLocation({
            mcc,
            mnc,
            cells: [cell],
            referenceLat,
            referenceLng
        });
        if (!loc || !isValidCoord(loc.latitude, loc.longitude)) {
            return null;
        }

        const distanceMeters = isValidCoord(referenceLat, referenceLng)
            ? haversineDistanceMeters(referenceLat, referenceLng, loc.latitude, loc.longitude)
            : null;

        return {
            mcc,
            mnc,
            lac: cell.lac,
            cellId: cell.cellId,
            signalStrength: cell.signalStrength || 0,
            latitude: loc.latitude,
            longitude: loc.longitude,
            accuracy: loc.accuracy || 300,
            locationType: 'CELL_TOWER',
            distanceMeters,
            usedReferenceLocation: false
        };
    }));

    const valid = resolved.filter(Boolean);

    if (isValidCoord(referenceLat, referenceLng)) {
        const nearby = valid
            .filter(t => t.distanceMeters !== null && t.distanceMeters <= MAX_PLAUSIBLE_TOWER_DISTANCE_M)
            .sort((a, b) => a.distanceMeters - b.distanceMeters);

        if (nearby.length > 0) {
            return nearby[0];
        }

        // LBS database placed every CID far away — keep the local Cell ID, do not jump the pin.
        const fallbackCell = strongestSignalCell(cells);
        return {
            mcc,
            mnc,
            lac: fallbackCell.lac,
            cellId: fallbackCell.cellId,
            signalStrength: fallbackCell.signalStrength || 0,
            latitude: referenceLat,
            longitude: referenceLng,
            accuracy: 300,
            locationType: 'CELL_TOWER',
            distanceMeters: 0,
            usedReferenceLocation: true
        };
    }

    if (valid.length > 0) {
        return valid.sort((a, b) => (b.signalStrength || -999) - (a.signalStrength || -999))[0];
    }

    return null;
}

module.exports = {
    resolveCellLocation,
    selectNearestCell,
    haversineDistanceMeters,
    MAX_PLAUSIBLE_TOWER_DISTANCE_M
};
